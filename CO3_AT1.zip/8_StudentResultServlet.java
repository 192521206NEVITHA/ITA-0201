import java.io.*;import jakarta.servlet.*;import jakarta.servlet.annotation.WebServlet;import jakarta.servlet.http.*;
@WebServlet("/StudentResultServlet")
public class StudentResultServlet extends HttpServlet{
protected void doPost(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException{
response.setContentType("text/html");PrintWriter out=response.getWriter();
String name=request.getParameter("name"),regno=request.getParameter("regno");
String[] v={request.getParameter("m1"),request.getParameter("m2"),request.getParameter("m3"),request.getParameter("m4"),request.getParameter("m5")};
try{
if(name==null||name.trim().isEmpty()||regno==null||regno.trim().isEmpty()){out.println("<h3>Please enter name and register number.</h3>");return;}
int[] m=new int[5];for(int i=0;i<5;i++){if(v[i]==null||v[i].trim().isEmpty()){out.println("<h3>Please enter all marks.</h3>");return;}m[i]=Integer.parseInt(v[i]);if(m[i]<0||m[i]>100){out.println("<h3>Marks must be between 0 and 100.</h3>");return;}}
int total=0,high=m[0],low=m[0];for(int x:m){total+=x;if(x>high)high=x;if(x<low)low=x;}double avg=total/5.0;
String grade=avg>=90?"A+":avg>=80?"A":avg>=70?"B":avg>=60?"C":avg>=50?"D":"F";boolean pass=true;for(int x:m)if(x<40)pass=false;
out.println("<html><body><h2>Student Result</h2><p>Name: "+name+"</p><p>Register Number: "+regno+"</p><table border='1' cellpadding='8'><tr><th>Subject</th><th>Mark</th></tr>");
for(int i=0;i<5;i++)out.println("<tr><td>Subject "+(i+1)+"</td><td>"+m[i]+"</td></tr>");
out.println("<tr><td>Total</td><td>"+total+"</td></tr><tr><td>Average</td><td>"+avg+"</td></tr><tr><td>Highest Mark</td><td>"+high+"</td></tr><tr><td>Lowest Mark</td><td>"+low+"</td></tr><tr><td>Grade</td><td>"+grade+"</td></tr><tr><td>Pass/Fail</td><td>"+(pass?"PASS":"FAIL")+"</td></tr></table></body></html>");
}catch(NumberFormatException e){out.println("<h3>Please enter numeric marks only.</h3>");}
}}