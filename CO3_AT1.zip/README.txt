CO3 Experiments 1 to 10 - Code

Experiments 1-5: Open the HTML files in a browser.
Experiments 6-10: Java Servlet programs requiring Apache Tomcat and Jakarta Servlet API.
Mappings:
6 /welcome
7 /StudentRegistrationServlet
8 /StudentResultServlet
9 /lifecycle
10 /visitor

The code follows the experiment titles and requirements in the uploaded CO3 Experiments document.
