import java.io.*;import java.time.LocalDateTime;
import jakarta.servlet.*;import jakarta.servlet.annotation.WebServlet;import jakarta.servlet.http.*;
@WebServlet("/welcome")
public class WelcomeServlet extends HttpServlet{
protected void doGet(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException{
response.setContentType("text/html");PrintWriter out=response.getWriter();
out.println("<html><body><h1>Welcome to Student Portal</h1>");
out.println("<p>Student Name: Nevitha</p><p>Course Name: Computer Science Engineering</p>");
out.println("<p>Current Date and Time: "+LocalDateTime.now()+"</p></body></html>");
}}