import java.io.*;import jakarta.servlet.*;import jakarta.servlet.annotation.WebServlet;import jakarta.servlet.http.*;
@WebServlet("/lifecycle")
public class ServletLifecycleServlet extends HttpServlet{
private int constructorCount=0,initCount=0,serviceCount=0;
public ServletLifecycleServlet(){constructorCount++;System.out.println("Constructor: "+constructorCount);}
public void init()throws ServletException{initCount++;System.out.println("init(): "+initCount);}
protected void service(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException{serviceCount++;System.out.println("service(): "+serviceCount);super.service(request,response);}
protected void doGet(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException{
response.setContentType("text/html");PrintWriter out=response.getWriter();
out.println("<html><body><h2>Servlet Lifecycle Demonstration</h2>");
out.println("<p>Constructor executions: "+constructorCount+"</p><p>init() executions: "+initCount+"</p><p>service() executions: "+serviceCount+"</p>");
out.println("<p>destroy() executes when the servlet is stopped or redeployed.</p></body></html>");}
public void destroy(){System.out.println("destroy() executed");}
}