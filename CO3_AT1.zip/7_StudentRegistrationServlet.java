import java.io.*;import jakarta.servlet.*;import jakarta.servlet.annotation.WebServlet;import jakarta.servlet.http.*;
@WebServlet("/StudentRegistrationServlet")
public class StudentRegistrationServlet extends HttpServlet{
protected void doPost(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException{
response.setContentType("text/html");PrintWriter out=response.getWriter();
String name=request.getParameter("name"),regno=request.getParameter("regno"),email=request.getParameter("email"),dept=request.getParameter("department"),sem=request.getParameter("semester");
if(name==null||name.trim().isEmpty()||regno==null||regno.trim().isEmpty()||email==null||email.trim().isEmpty()||dept==null||dept.trim().isEmpty()||sem==null||sem.trim().isEmpty()){out.println("<h3>Please fill all the fields.</h3>");return;}
out.println("<html><body><h2>Submitted Student Details</h2>");
out.println("<p>Name: "+name+"</p><p>Register Number: "+regno+"</p><p>Email: "+email+"</p><p>Department: "+dept+"</p><p>Semester: "+sem+"</p>");
out.println("</body></html>");
}}