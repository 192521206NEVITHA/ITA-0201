import java.io.*;import java.util.concurrent.atomic.AtomicInteger;
import jakarta.servlet.*;import jakarta.servlet.annotation.WebServlet;import jakarta.servlet.http.*;
@WebServlet("/visitor")
public class ThreadSafeVisitorCounterServlet extends HttpServlet{
private final AtomicInteger visitorCount=new AtomicInteger(0);
protected void doGet(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException{
response.setContentType("text/html");PrintWriter out=response.getWriter();
int count=visitorCount.incrementAndGet();
out.println("<html><body><h2>Thread-Safe Visitor Counter</h2><p>Total Visitors: "+count+"</p>");
out.println("<p>AtomicInteger prevents lost updates during concurrent requests.</p>");
out.println("<p>Request-specific values should be local variables.</p></body></html>");}
}
/* Unsafe: private int visitorCount=0; visitorCount++;
   Safe: AtomicInteger and incrementAndGet(). */